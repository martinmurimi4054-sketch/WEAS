"""Job tracking endpoints — used by the frontend to poll render progress."""
from fastapi import APIRouter, HTTPException
from services.job_manager import JobManager

router      = APIRouter()
job_manager = JobManager()


@router.get("/{job_id}")
async def get_job(job_id: str):
    job = job_manager.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    # Remove internal paths from public response
    safe = {k: v for k, v in job.items() if k not in ("input_path",)}
    return safe


@router.get("/")
async def list_jobs():
    return {"jobs": [
        {k: v for k, v in j.items() if k not in ("input_path",)}
        for j in job_manager.all_jobs()
    ]}


@router.delete("/{job_id}")
async def cancel_job(job_id: str):
    job = job_manager.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    job_manager.update(job_id, {"status": "cancelled"})
    return {"message": "Job cancelled"}
