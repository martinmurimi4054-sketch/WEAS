"""Video upload and transformation API endpoints."""
from fastapi import APIRouter, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional
import uuid, os, asyncio, shutil

from services.ai_pipeline import AnimePipeline, TransformConfig, PipelineProgress, PipelineStage
from services.job_manager import JobManager

router      = APIRouter()
pipeline    = AnimePipeline()
job_manager = JobManager()

UPLOAD_DIR = "uploads"
OUTPUT_DIR = "outputs"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

ALLOWED_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".webm"}
MAX_FILE_SIZE_GB = 2


class TransformRequest(BaseModel):
    job_id:       str
    animal:       str = "wolf"
    prompt:       str = ""
    style_preset: str = "anime"
    emotion:      str = "Sad"
    voice_style:  str = "female"
    quality:      str = "1080p"
    bg_replace:   bool = False


@router.post("/upload")
async def upload_video(file: UploadFile = File(...)):
    """Accept a video file and return a job_id for tracking."""
    ext = os.path.splitext(file.filename or "")[-1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, f"Unsupported format: {ext}. Allowed: {ALLOWED_EXTENSIONS}")

    job_id   = str(uuid.uuid4())
    save_dir = os.path.join(UPLOAD_DIR, job_id)
    os.makedirs(save_dir, exist_ok=True)
    dest     = os.path.join(save_dir, f"input{ext}")

    total = 0
    with open(dest, "wb") as f:
        while chunk := await file.read(1024 * 1024):  # 1 MB chunks
            total += len(chunk)
            if total > MAX_FILE_SIZE_GB * 1024**3:
                raise HTTPException(413, "File exceeds 2 GB limit")
            f.write(chunk)

    job_manager.create(job_id, {"input_path": dest, "filename": file.filename})
    return {"job_id": job_id, "filename": file.filename, "size_mb": round(total/1024**2, 1)}


@router.post("/transform")
async def start_transform(req: TransformRequest, background: BackgroundTasks):
    """Queue an AI transformation job."""
    job = job_manager.get(req.job_id)
    if not job:
        raise HTTPException(404, "Job not found. Upload a video first.")

    cfg = TransformConfig(
        job_id       = req.job_id,
        input_path   = job["input_path"],
        output_dir   = os.path.join(OUTPUT_DIR, req.job_id),
        animal       = req.animal,
        prompt       = req.prompt,
        style_preset = req.style_preset,
        emotion      = req.emotion,
        voice_style  = req.voice_style,
        quality      = req.quality,
        bg_replace   = req.bg_replace,
    )

    job_manager.update(req.job_id, {"status": "queued", "config": req.dict()})
    background.add_task(_run_pipeline, cfg)
    return {"job_id": req.job_id, "status": "queued", "message": "Transformation queued"}


@router.get("/download/{job_id}")
async def download_result(job_id: str):
    """Return the final rendered video file."""
    job = job_manager.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    if job.get("status") != "done":
        raise HTTPException(409, f"Job status: {job.get('status')}. Not ready.")
    out = job.get("output_path")
    if not out or not os.path.exists(out):
        raise HTTPException(500, "Output file missing")
    return FileResponse(out, media_type="video/mp4",
                        headers={"Content-Disposition": f'attachment; filename="anime_{job_id}.mp4"'})


async def _run_pipeline(cfg: TransformConfig):
    """Background task that runs the full AI pipeline."""
    async def on_progress(p: PipelineProgress):
        job_manager.update(cfg.job_id, {
            "status":  p.stage.value,
            "pct":     p.pct,
            "message": p.message,
        })
        if p.stage == PipelineStage.DONE:
            job_manager.update(cfg.job_id, {"status": "done", "output_path": p.output_path})
        if p.stage == PipelineStage.ERROR:
            job_manager.update(cfg.job_id, {"status": "error", "error": p.error})

    try:
        await pipeline.run(cfg, on_progress)
    except Exception as e:
        job_manager.update(cfg.job_id, {"status": "error", "error": str(e)})
