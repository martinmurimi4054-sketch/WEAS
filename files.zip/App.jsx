import { useState, useRef, useCallback, useEffect } from "react";

/* ─────────────────────────────────────────────
   DATA CONSTANTS
───────────────────────────────────────────── */
const ANIMALS = [
  { id: "lion",    name: "Lion",    icon: "🦁", desc: "Lion King Anime",     accent: "#f59e0b" },
  { id: "wolf",    name: "Wolf",    icon: "🐺", desc: "Emotional Wolf",       accent: "#818cf8" },
  { id: "cat",     name: "Cat",     icon: "🐱", desc: "Neko Anime",          accent: "#f472b6" },
  { id: "tiger",   name: "Tiger",   icon: "🐯", desc: "Warrior Tiger",       accent: "#fb923c" },
  { id: "fox",     name: "Fox",     icon: "🦊", desc: "Disney Fox",          accent: "#f97316" },
  { id: "panda",   name: "Panda",   icon: "🐼", desc: "Cute Panda",          accent: "#a3e635" },
  { id: "eagle",   name: "Eagle",   icon: "🦅", desc: "Sky Eagle",           accent: "#38bdf8" },
  { id: "rabbit",  name: "Rabbit",  icon: "🐰", desc: "Bunny Anime",         accent: "#f9a8d4" },
  { id: "bear",    name: "Bear",    icon: "🐻", desc: "Cinematic Bear",      accent: "#92400e" },
  { id: "custom",  name: "Custom",  icon: "✨", desc: "Fantasy Creature",    accent: "#c084fc" },
];

const PROMPT_EXAMPLES = [
  "Turn everyone into emotional anime wolves under a blue moonlit sky",
  "Make this video look like a Pixar-quality lion king anime musical",
  "Convert the singer into a cute panda anime with glowing eyes",
  "Transform all characters into mystical fox anime with cherry blossoms",
  "Create a sad cinematic wolf anime with dramatic blue lighting and emotional voice",
];

const PROCESSING_STAGES = [
  { id: "upload",    label: "Uploading Video",          icon: "⬆",  duration: 800  },
  { id: "analyze",   label: "Analyzing Faces & Bodies", icon: "👁",  duration: 3000 },
  { id: "emotion",   label: "Mapping Emotions & Lips",  icon: "😊",  duration: 2500 },
  { id: "scene",     label: "Analyzing Scene & Light",  icon: "🎬",  duration: 2000 },
  { id: "music",     label: "Processing Audio & Lyrics",icon: "🎵",  duration: 2000 },
  { id: "generate",  label: "Generating Anime Characters",icon: "🎨", duration: 4000 },
  { id: "voice",     label: "Converting Voices",        icon: "🎤",  duration: 2500 },
  { id: "lipsync",   label: "Syncing Lips & Motion",    icon: "🎭",  duration: 2000 },
  { id: "subtitles", label: "Rendering Subtitles",      icon: "📝",  duration: 1500 },
  { id: "finalize",  label: "Final Render & Export",    icon: "✨",  duration: 3000 },
];

const STYLE_PRESETS = [
  { label: "Pixar Quality",   value: "pixar"   },
  { label: "Classic Anime",   value: "anime"   },
  { label: "Disney Style",    value: "disney"  },
  { label: "Ghibli Soft",     value: "ghibli"  },
  { label: "Cinematic Dark",  value: "dark"    },
  { label: "Neon Cyberpunk",  value: "cyber"   },
];

const EMOTIONS = ["Joyful","Sad","Epic","Mysterious","Romantic","Intense","Dreamy","Fierce"];

/* ─────────────────────────────────────────────
   HOOKS
───────────────────────────────────────────── */
function useProcessing(onComplete) {
  const [stage, setStage]       = useState(-1);
  const [progress, setProgress] = useState(0);
  const [running, setRunning]   = useState(false);
  const timers = useRef([]);

  const start = useCallback(() => {
    setRunning(true);
    setStage(0);
    setProgress(0);
    let cumulative = 0;
    PROCESSING_STAGES.forEach((s, i) => {
      const t1 = setTimeout(() => setStage(i), cumulative);
      const t2 = setTimeout(() => {
        const pct = Math.round(((i + 1) / PROCESSING_STAGES.length) * 100);
        setProgress(pct);
      }, cumulative + s.duration / 2);
      cumulative += s.duration;
      timers.current.push(t1, t2);
    });
    const total = PROCESSING_STAGES.reduce((a, s) => a + s.duration, 0);
    const done = setTimeout(() => {
      setRunning(false);
      setStage(-1);
      setProgress(100);
      onComplete();
    }, total);
    timers.current.push(done);
  }, [onComplete]);

  const reset = useCallback(() => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
    setStage(-1);
    setProgress(0);
    setRunning(false);
  }, []);

  return { stage, progress, running, start, reset };
}

/* ─────────────────────────────────────────────
   SUB-COMPONENTS
───────────────────────────────────────────── */

function ParticlesBg() {
  return (
    <div style={{position:"fixed",inset:0,overflow:"hidden",pointerEvents:"none",zIndex:0}}>
      {Array.from({length:30}).map((_,i)=>(
        <div key={i} style={{
          position:"absolute",
          width: `${2 + (i%4)}px`,
          height: `${2 + (i%4)}px`,
          borderRadius:"50%",
          background: i%3===0 ? "#06b6d4" : i%3===1 ? "#8b5cf6" : "#f59e0b",
          opacity: 0.15 + (i%5)*0.04,
          left:`${(i*37)%100}%`,
          top:`${(i*53)%100}%`,
          animation:`float-${i%3} ${8+(i%7)}s ease-in-out infinite`,
          animationDelay:`${(i*0.7)%5}s`,
        }}/>
      ))}
      <style>{`
        @keyframes float-0 { 0%,100%{transform:translateY(0px)} 50%{transform:translateY(-20px)} }
        @keyframes float-1 { 0%,100%{transform:translateY(0px) translateX(0px)} 50%{transform:translateY(-15px) translateX(10px)} }
        @keyframes float-2 { 0%,100%{transform:translateY(0px)} 33%{transform:translateY(-25px)} 66%{transform:translateY(-10px)} }
      `}</style>
    </div>
  );
}

function Logo() {
  return (
    <div style={{display:"flex",alignItems:"center",gap:"10px"}}>
      <div style={{
        width:40,height:40,borderRadius:12,
        background:"linear-gradient(135deg,#06b6d4,#8b5cf6)",
        display:"flex",alignItems:"center",justifyContent:"center",
        fontSize:20,boxShadow:"0 0 20px rgba(6,182,212,0.4)"
      }}>🎬</div>
      <div>
        <div style={{fontFamily:"'Exo 2',sans-serif",fontWeight:800,fontSize:16,color:"#e2e8f0",letterSpacing:"-0.3px",lineHeight:1}}>
          ANIME<span style={{color:"#06b6d4"}}>ANIMAL</span>
        </div>
        <div style={{fontSize:9,color:"#475569",letterSpacing:"2px",fontWeight:600,textTransform:"uppercase"}}>VIDEO STUDIO</div>
      </div>
    </div>
  );
}

function GlowButton({ children, onClick, variant="primary", disabled=false, style={} }) {
  const base = {
    padding:"10px 20px",
    borderRadius:10,
    border:"none",
    cursor: disabled ? "not-allowed" : "pointer",
    fontWeight:700,
    fontSize:14,
    transition:"all 0.2s",
    opacity: disabled ? 0.5 : 1,
    ...style,
  };
  const styles = {
    primary: { background:"linear-gradient(135deg,#06b6d4,#0891b2)", color:"#fff", boxShadow:"0 0 20px rgba(6,182,212,0.4)" },
    purple:  { background:"linear-gradient(135deg,#8b5cf6,#7c3aed)", color:"#fff", boxShadow:"0 0 20px rgba(139,92,246,0.4)" },
    amber:   { background:"linear-gradient(135deg,#f59e0b,#d97706)", color:"#fff", boxShadow:"0 0 20px rgba(245,158,11,0.4)" },
    ghost:   { background:"transparent", color:"#94a3b8", border:"1px solid #334155" },
  };
  return (
    <button
      onClick={disabled ? undefined : onClick}
      style={{...base, ...styles[variant]}}
      onMouseEnter={e=>{ if(!disabled) e.currentTarget.style.transform="translateY(-2px) scale(1.02)" }}
      onMouseLeave={e=>{ e.currentTarget.style.transform="none" }}
    >
      {children}
    </button>
  );
}

function Card({ children, style={}, glow=false }) {
  return (
    <div style={{
      background:"rgba(15,23,42,0.8)",
      border: glow ? "1px solid rgba(6,182,212,0.3)" : "1px solid rgba(51,65,85,0.8)",
      borderRadius:16,
      padding:"20px",
      backdropFilter:"blur(12px)",
      boxShadow: glow ? "0 0 30px rgba(6,182,212,0.1),inset 0 1px 0 rgba(255,255,255,0.05)" : "inset 0 1px 0 rgba(255,255,255,0.05)",
      ...style,
    }}>
      {children}
    </div>
  );
}

/* ─────────────────────────────────────────────
   VIEWS
───────────────────────────────────────────── */

function UploadView({ onFileSelected }) {
  const [dragging, setDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef();

  const handleFile = useCallback((file) => {
    if (!file) return;
    setUploading(true);
    setUploadProgress(0);
    const interval = setInterval(() => {
      setUploadProgress(p => {
        if (p >= 100) { clearInterval(interval); setTimeout(() => onFileSelected(file), 400); return 100; }
        return p + Math.random() * 15;
      });
    }, 100);
  }, [onFileSelected]);

  const onDrop = useCallback((e) => {
    e.preventDefault();
    setDragging(false);
    handleFile(e.dataTransfer.files[0]);
  }, [handleFile]);

  return (
    <div style={{maxWidth:720,margin:"0 auto",paddingTop:40}}>
      <div style={{textAlign:"center",marginBottom:32}}>
        <div style={{fontSize:42,marginBottom:12}}>🎬</div>
        <h1 style={{fontFamily:"'Exo 2',sans-serif",fontWeight:800,fontSize:32,color:"#e2e8f0",margin:0,letterSpacing:"-1px"}}>
          Upload Your Video
        </h1>
        <p style={{color:"#64748b",marginTop:8,fontSize:15}}>
          MP4 · MOV · AVI · Up to 2GB · Any length
        </p>
      </div>

      <Card glow={dragging}>
        <div
          onDrop={onDrop}
          onDragOver={e=>{e.preventDefault();setDragging(true)}}
          onDragLeave={()=>setDragging(false)}
          onClick={()=>inputRef.current?.click()}
          style={{
            border:`2px dashed ${dragging ? "#06b6d4" : "#1e293b"}`,
            borderRadius:12,
            padding:"60px 40px",
            textAlign:"center",
            cursor:"pointer",
            transition:"all 0.3s",
            background: dragging ? "rgba(6,182,212,0.05)" : "transparent",
          }}
        >
          <input ref={inputRef} type="file" accept=".mp4,.mov,.avi" style={{display:"none"}} onChange={e=>handleFile(e.target.files[0])}/>
          <div style={{fontSize:56,marginBottom:16}}>{dragging ? "🌊" : "📁"}</div>
          <div style={{color:"#94a3b8",fontSize:18,fontWeight:600,marginBottom:8}}>
            {dragging ? "Drop to transform!" : "Drag & drop your video here"}
          </div>
          <div style={{color:"#475569",fontSize:14,marginBottom:20}}>
            or click to browse files
          </div>
          {!uploading && (
            <GlowButton>Choose File</GlowButton>
          )}
          {uploading && (
            <div style={{marginTop:16}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                <span style={{color:"#94a3b8",fontSize:13}}>Uploading...</span>
                <span style={{color:"#06b6d4",fontSize:13,fontWeight:700}}>{Math.min(100,Math.round(uploadProgress))}%</span>
              </div>
              <div style={{height:6,background:"#1e293b",borderRadius:3,overflow:"hidden"}}>
                <div style={{
                  height:"100%",
                  width:`${Math.min(100,uploadProgress)}%`,
                  background:"linear-gradient(90deg,#06b6d4,#8b5cf6)",
                  borderRadius:3,
                  transition:"width 0.1s",
                  boxShadow:"0 0 10px rgba(6,182,212,0.6)",
                }}/>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Supported formats */}
      <div style={{display:"flex",gap:12,marginTop:20,justifyContent:"center"}}>
        {["MP4","MOV","AVI","MKV"].map(fmt=>(
          <div key={fmt} style={{
            padding:"4px 14px",
            background:"rgba(6,182,212,0.1)",
            border:"1px solid rgba(6,182,212,0.2)",
            borderRadius:20,
            color:"#06b6d4",
            fontSize:12,
            fontWeight:700,
            letterSpacing:"0.5px",
          }}>{fmt}</div>
        ))}
      </div>

      {/* Quick start examples */}
      <div style={{marginTop:32}}>
        <div style={{color:"#475569",fontSize:12,fontWeight:600,letterSpacing:"1px",textTransform:"uppercase",marginBottom:12,textAlign:"center"}}>
          Or start with a demo
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}}>
          {["Music Video","Dance Video","Movie Scene"].map(demo=>(
            <button key={demo} onClick={()=>onFileSelected({name:demo+".mp4",demo:true,demoType:demo})} style={{
              background:"rgba(30,41,59,0.8)",
              border:"1px solid #1e293b",
              borderRadius:10,
              padding:"12px",
              color:"#94a3b8",
              fontSize:13,
              cursor:"pointer",
              transition:"all 0.2s",
              fontWeight:500,
            }}
            onMouseEnter={e=>{e.currentTarget.style.borderColor="#06b6d4";e.currentTarget.style.color="#e2e8f0"}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor="#1e293b";e.currentTarget.style.color="#94a3b8"}}
            >
              🎬 {demo}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function ConfigView({ file, onStart }) {
  const [selectedAnimal, setSelectedAnimal] = useState("wolf");
  const [prompt, setPrompt]                 = useState("");
  const [stylePreset, setStylePreset]       = useState("anime");
  const [emotion, setEmotion]               = useState("Sad");
  const [voiceStyle, setVoiceStyle]         = useState("female");
  const [quality, setQuality]               = useState("1080p");
  const [bgReplace, setBgReplace]           = useState(false);
  const [showExamples, setShowExamples]     = useState(false);

  const animal = ANIMALS.find(a => a.id === selectedAnimal);

  return (
    <div style={{maxWidth:900,margin:"0 auto",paddingTop:20}}>
      <div style={{marginBottom:24}}>
        <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:6}}>
          <span style={{fontSize:24}}>🎯</span>
          <h2 style={{fontFamily:"'Exo 2',sans-serif",fontWeight:800,fontSize:26,color:"#e2e8f0",margin:0}}>
            Configure Your Transformation
          </h2>
        </div>
        <div style={{color:"#475569",fontSize:14,paddingLeft:36}}>
          {file?.name || "demo.mp4"} · Ready for transformation
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20}}>
        {/* LEFT COLUMN */}
        <div style={{display:"flex",flexDirection:"column",gap:16}}>

          {/* Animal Selector */}
          <Card>
            <div style={{color:"#94a3b8",fontSize:11,fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:14}}>
              Choose Animal Style
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:8}}>
              {ANIMALS.map(a=>(
                <button key={a.id} onClick={()=>setSelectedAnimal(a.id)} style={{
                  background: selectedAnimal===a.id ? `rgba(${hexToRgb(a.accent)},0.15)` : "rgba(15,23,42,0.5)",
                  border: selectedAnimal===a.id ? `1.5px solid ${a.accent}` : "1px solid #1e293b",
                  borderRadius:10,
                  padding:"10px 4px",
                  cursor:"pointer",
                  transition:"all 0.2s",
                  textAlign:"center",
                }}>
                  <div style={{fontSize:22,marginBottom:4}}>{a.icon}</div>
                  <div style={{fontSize:10,color: selectedAnimal===a.id ? a.accent : "#64748b",fontWeight:700,lineHeight:1}}>
                    {a.name}
                  </div>
                </button>
              ))}
            </div>
            {animal && (
              <div style={{
                marginTop:12,
                padding:"8px 12px",
                background:`rgba(${hexToRgb(animal.accent)},0.08)`,
                border:`1px solid rgba(${hexToRgb(animal.accent)},0.2)`,
                borderRadius:8,
                fontSize:12,
                color: animal.accent,
                fontWeight:600,
              }}>
                {animal.icon} {animal.desc} selected
              </div>
            )}
          </Card>

          {/* Style & Emotion */}
          <Card>
            <div style={{color:"#94a3b8",fontSize:11,fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:14}}>
              Animation Style
            </div>
            <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:16}}>
              {STYLE_PRESETS.map(s=>(
                <button key={s.value} onClick={()=>setStylePreset(s.value)} style={{
                  padding:"6px 14px",
                  borderRadius:20,
                  border: stylePreset===s.value ? "1px solid #06b6d4" : "1px solid #1e293b",
                  background: stylePreset===s.value ? "rgba(6,182,212,0.15)" : "transparent",
                  color: stylePreset===s.value ? "#06b6d4" : "#64748b",
                  fontSize:12,
                  fontWeight:600,
                  cursor:"pointer",
                  transition:"all 0.2s",
                }}>
                  {s.label}
                </button>
              ))}
            </div>
            <div style={{color:"#94a3b8",fontSize:11,fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:10}}>
              Emotion Intensity
            </div>
            <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
              {EMOTIONS.map(e=>(
                <button key={e} onClick={()=>setEmotion(e)} style={{
                  padding:"5px 12px",
                  borderRadius:20,
                  border: emotion===e ? "1px solid #8b5cf6" : "1px solid #1e293b",
                  background: emotion===e ? "rgba(139,92,246,0.15)" : "transparent",
                  color: emotion===e ? "#a78bfa" : "#64748b",
                  fontSize:12,
                  fontWeight:600,
                  cursor:"pointer",
                  transition:"all 0.2s",
                }}>
                  {e}
                </button>
              ))}
            </div>
          </Card>

          {/* Voice & Quality */}
          <Card>
            <div style={{color:"#94a3b8",fontSize:11,fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:14}}>
              Voice & Output
            </div>
            <div style={{display:"flex",gap:16,marginBottom:14}}>
              <div style={{flex:1}}>
                <div style={{color:"#64748b",fontSize:12,marginBottom:8}}>Anime Voice</div>
                <div style={{display:"flex",gap:8}}>
                  {["female","male","both"].map(v=>(
                    <button key={v} onClick={()=>setVoiceStyle(v)} style={{
                      flex:1,padding:"7px",borderRadius:8,
                      border: voiceStyle===v ? "1px solid #f472b6" : "1px solid #1e293b",
                      background: voiceStyle===v ? "rgba(244,114,182,0.15)" : "transparent",
                      color: voiceStyle===v ? "#f472b6" : "#64748b",
                      fontSize:12,fontWeight:600,cursor:"pointer",transition:"all 0.2s",
                      textTransform:"capitalize",
                    }}>{v}</button>
                  ))}
                </div>
              </div>
              <div style={{flex:1}}>
                <div style={{color:"#64748b",fontSize:12,marginBottom:8}}>Export Quality</div>
                <div style={{display:"flex",gap:8}}>
                  {["720p","1080p","4K"].map(q=>(
                    <button key={q} onClick={()=>setQuality(q)} style={{
                      flex:1,padding:"7px",borderRadius:8,
                      border: quality===q ? "1px solid #f59e0b" : "1px solid #1e293b",
                      background: quality===q ? "rgba(245,158,11,0.15)" : "transparent",
                      color: quality===q ? "#f59e0b" : "#64748b",
                      fontSize:12,fontWeight:700,cursor:"pointer",transition:"all 0.2s",
                    }}>{q}</button>
                  ))}
                </div>
              </div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:10,paddingTop:10,borderTop:"1px solid #1e293b"}}>
              <div onClick={()=>setBgReplace(!bgReplace)} style={{
                width:36,height:20,borderRadius:10,
                background: bgReplace ? "#06b6d4" : "#1e293b",
                position:"relative",cursor:"pointer",transition:"background 0.3s",
                flexShrink:0,
              }}>
                <div style={{
                  position:"absolute",top:2,left: bgReplace?16:2,
                  width:16,height:16,borderRadius:"50%",background:"#fff",
                  transition:"left 0.3s",boxShadow:"0 1px 3px rgba(0,0,0,0.3)",
                }}/>
              </div>
              <span style={{color:"#94a3b8",fontSize:13}}>AI Background Replacement</span>
            </div>
          </Card>
        </div>

        {/* RIGHT COLUMN */}
        <div style={{display:"flex",flexDirection:"column",gap:16}}>
          {/* Prompt Box */}
          <Card glow>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
              <div style={{color:"#94a3b8",fontSize:11,fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase"}}>
                AI Transformation Prompt
              </div>
              <button onClick={()=>setShowExamples(!showExamples)} style={{
                background:"rgba(6,182,212,0.1)",border:"1px solid rgba(6,182,212,0.2)",
                borderRadius:6,padding:"3px 10px",color:"#06b6d4",fontSize:11,fontWeight:600,cursor:"pointer",
              }}>
                {showExamples ? "Hide" : "Examples"}
              </button>
            </div>

            {showExamples && (
              <div style={{marginBottom:12,display:"flex",flexDirection:"column",gap:6}}>
                {PROMPT_EXAMPLES.map((ex,i)=>(
                  <button key={i} onClick={()=>{setPrompt(ex);setShowExamples(false)}} style={{
                    background:"rgba(15,23,42,0.8)",border:"1px solid #1e293b",borderRadius:8,
                    padding:"8px 12px",color:"#64748b",fontSize:12,cursor:"pointer",
                    textAlign:"left",transition:"all 0.2s",lineHeight:1.4,
                  }}
                  onMouseEnter={e=>{e.currentTarget.style.color="#e2e8f0";e.currentTarget.style.borderColor="#334155"}}
                  onMouseLeave={e=>{e.currentTarget.style.color="#64748b";e.currentTarget.style.borderColor="#1e293b"}}
                  >
                    ✦ {ex}
                  </button>
                ))}
              </div>
            )}

            <textarea
              value={prompt}
              onChange={e=>setPrompt(e.target.value)}
              placeholder={`Describe your vision...\n\nExample: "Transform everyone into emotional anime wolves under a dramatic blue moonlit sky with cinematic lighting and expressive singing voices"`}
              style={{
                width:"100%",minHeight:140,background:"rgba(15,23,42,0.6)",
                border:"1px solid #1e293b",borderRadius:10,padding:14,
                color:"#e2e8f0",fontSize:14,lineHeight:1.6,resize:"vertical",
                fontFamily:"inherit",outline:"none",boxSizing:"border-box",
                transition:"border-color 0.2s",
              }}
              onFocus={e=>e.target.style.borderColor="#06b6d4"}
              onBlur={e=>e.target.style.borderColor="#1e293b"}
            />
            <div style={{display:"flex",justifyContent:"flex-end",marginTop:8}}>
              <span style={{color:"#334155",fontSize:12}}>{prompt.length} chars</span>
            </div>
          </Card>

          {/* Preview summary */}
          <Card>
            <div style={{color:"#94a3b8",fontSize:11,fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:14}}>
              Transformation Summary
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:10}}>
              {[
                {label:"Animal",     value:`${animal?.icon} ${animal?.desc}`},
                {label:"Style",      value:STYLE_PRESETS.find(s=>s.value===stylePreset)?.label},
                {label:"Emotion",    value:emotion},
                {label:"Voice",      value:`${voiceStyle} anime voice`},
                {label:"Quality",    value:quality},
                {label:"BG Replace", value:bgReplace?"Enabled":"Disabled"},
              ].map(row=>(
                <div key={row.label} style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <span style={{color:"#475569",fontSize:13}}>{row.label}</span>
                  <span style={{color:"#94a3b8",fontSize:13,fontWeight:600}}>{row.value}</span>
                </div>
              ))}
            </div>
            <div style={{
              marginTop:16,padding:"10px 14px",
              background:"rgba(6,182,212,0.06)",border:"1px solid rgba(6,182,212,0.15)",
              borderRadius:8,fontSize:12,color:"#64748b",lineHeight:1.5,
            }}>
              🕐 Estimated render time: <strong style={{color:"#06b6d4"}}>5–7 minutes</strong> for optimal quality
            </div>
          </Card>

          {/* START BUTTON */}
          <GlowButton
            onClick={()=>onStart({selectedAnimal,prompt,stylePreset,emotion,voiceStyle,quality,bgReplace})}
            style={{width:"100%",padding:"16px",fontSize:17,borderRadius:12,letterSpacing:"0.5px"}}
          >
            🚀 Start AI Transformation
          </GlowButton>
        </div>
      </div>
    </div>
  );
}

function ProcessingView({ config, onComplete }) {
  const { stage, progress, running, start } = useProcessing(onComplete);
  const animal = ANIMALS.find(a => a.id === config.selectedAnimal) || ANIMALS[1];
  const totalTime = PROCESSING_STAGES.reduce((a,s)=>a+s.duration,0) / 1000;

  useEffect(()=>{ start(); }, []);

  const stageTimeMs = PROCESSING_STAGES.reduce((acc,s,i)=> {
    acc[i] = acc[i-1] ? acc[i-1]+s.duration : s.duration; return acc;
  }, {});
  const elapsed = stage >= 0 ? stageTimeMs[stage] : 0;
  const timeLeft = Math.max(0, Math.round((totalTime*1000 - elapsed)/1000));

  return (
    <div style={{maxWidth:700,margin:"0 auto",paddingTop:30}}>
      {/* Header */}
      <div style={{textAlign:"center",marginBottom:36}}>
        <div style={{
          width:100,height:100,borderRadius:"50%",
          background:`radial-gradient(circle, rgba(${hexToRgb(animal.accent)},0.2), transparent)`,
          border:`2px solid rgba(${hexToRgb(animal.accent)},0.4)`,
          display:"flex",alignItems:"center",justifyContent:"center",
          fontSize:50,margin:"0 auto 20px",
          animation:"pulse-ring 2s ease-in-out infinite",
        }}>
          {animal.icon}
        </div>
        <h2 style={{fontFamily:"'Exo 2',sans-serif",fontWeight:800,fontSize:28,color:"#e2e8f0",margin:0}}>
          AI Transformation In Progress
        </h2>
        <p style={{color:"#64748b",marginTop:8,fontSize:14}}>
          {config.stylePreset} · {animal.desc} · {config.emotion} · {config.quality}
        </p>
        <style>{`@keyframes pulse-ring { 0%,100%{box-shadow:0 0 0 0 rgba(${hexToRgb(animal.accent)},0.3)} 50%{box-shadow:0 0 0 20px rgba(${hexToRgb(animal.accent)},0)} }`}</style>
      </div>

      {/* Overall progress */}
      <Card glow style={{marginBottom:20}}>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
          <span style={{color:"#94a3b8",fontWeight:700,fontSize:14}}>Overall Progress</span>
          <span style={{color:"#06b6d4",fontWeight:800,fontSize:18}}>{progress}%</span>
        </div>
        <div style={{height:10,background:"#0f172a",borderRadius:5,overflow:"hidden",marginBottom:10}}>
          <div style={{
            height:"100%",
            width:`${progress}%`,
            background:`linear-gradient(90deg,#06b6d4,${animal.accent},#8b5cf6)`,
            borderRadius:5,
            transition:"width 0.5s ease",
            boxShadow:`0 0 15px rgba(6,182,212,0.5)`,
          }}/>
        </div>
        {running && (
          <div style={{display:"flex",justifyContent:"space-between",fontSize:12}}>
            <span style={{color:"#475569"}}>
              {stage >= 0 ? `${PROCESSING_STAGES[stage].icon} ${PROCESSING_STAGES[stage].label}` : "Initializing..."}
            </span>
            <span style={{color:"#475569"}}>~{timeLeft}s remaining</span>
          </div>
        )}
      </Card>

      {/* Stage list */}
      <Card>
        <div style={{display:"flex",flexDirection:"column",gap:0}}>
          {PROCESSING_STAGES.map((s,i)=>{
            const done = i < stage || (progress===100);
            const active = i === stage && running;
            return (
              <div key={s.id} style={{
                display:"flex",alignItems:"center",gap:14,
                padding:"10px 0",
                borderBottom: i < PROCESSING_STAGES.length-1 ? "1px solid rgba(30,41,59,0.6)" : "none",
                transition:"all 0.3s",
              }}>
                <div style={{
                  width:32,height:32,borderRadius:"50%",
                  background: done ? "rgba(6,182,212,0.2)" : active ? "rgba(139,92,246,0.2)" : "rgba(15,23,42,0.8)",
                  border: done ? "1.5px solid #06b6d4" : active ? "1.5px solid #8b5cf6" : "1.5px solid #1e293b",
                  display:"flex",alignItems:"center",justifyContent:"center",
                  fontSize:14,flexShrink:0,
                  animation: active ? "spin 1.5s linear infinite" : "none",
                  transition:"all 0.3s",
                }}>
                  {done ? "✓" : s.icon}
                </div>
                <div style={{flex:1}}>
                  <div style={{
                    fontSize:13,fontWeight:600,
                    color: done ? "#06b6d4" : active ? "#a78bfa" : "#475569",
                    transition:"color 0.3s",
                  }}>
                    {s.label}
                  </div>
                  {active && (
                    <div style={{height:3,background:"#0f172a",borderRadius:2,marginTop:5,overflow:"hidden"}}>
                      <div style={{
                        height:"100%",width:"60%",
                        background:"linear-gradient(90deg,#8b5cf6,transparent)",
                        animation:"slide 1.2s ease-in-out infinite",
                      }}/>
                    </div>
                  )}
                </div>
                <div style={{
                  fontSize:11,fontWeight:700,
                  color: done ? "#06b6d4" : active ? "#8b5cf6" : "#334155",
                }}>
                  {done ? "DONE" : active ? "RUNNING" : "QUEUE"}
                </div>
              </div>
            );
          })}
        </div>
        <style>{`
          @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
          @keyframes slide { 0%{transform:translateX(-100%)} 100%{transform:translateX(200%)} }
        `}</style>
      </Card>

      {/* Prompt preview */}
      {config.prompt && (
        <div style={{
          marginTop:16,padding:"12px 16px",
          background:"rgba(8,145,178,0.06)",
          border:"1px solid rgba(6,182,212,0.15)",
          borderRadius:10,fontSize:13,color:"#64748b",
          lineHeight:1.5,fontStyle:"italic",
        }}>
          ✦ "{config.prompt}"
        </div>
      )}
    </div>
  );
}

function ResultsView({ config, onNewVideo }) {
  const [downloading, setDownloading] = useState(false);
  const [sliderPos, setSliderPos]     = useState(50);
  const animal = ANIMALS.find(a => a.id === config.selectedAnimal) || ANIMALS[1];

  const handleDownload = (quality) => {
    setDownloading(true);
    setTimeout(() => {
      setDownloading(false);
      alert(`✅ "${animal.desc} Transformation" downloaded in ${quality}!`);
    }, 1500);
  };

  return (
    <div style={{maxWidth:820,margin:"0 auto",paddingTop:20}}>
      {/* Success header */}
      <div style={{textAlign:"center",marginBottom:28}}>
        <div style={{fontSize:48,marginBottom:10}}>🎉</div>
        <h2 style={{fontFamily:"'Exo 2',sans-serif",fontWeight:800,fontSize:28,color:"#e2e8f0",margin:0}}>
          Transformation Complete!
        </h2>
        <p style={{color:"#64748b",marginTop:8,fontSize:14}}>
          Your {animal.desc} anime video is ready
        </p>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 340px",gap:20}}>
        {/* Video preview */}
        <div>
          <Card glow style={{padding:0,overflow:"hidden",marginBottom:16}}>
            {/* Before/After Slider */}
            <div style={{position:"relative",height:300,background:"#0a0f1a",overflow:"hidden",userSelect:"none"}}
              onMouseMove={e=>{const r=e.currentTarget.getBoundingClientRect();setSliderPos(Math.round(((e.clientX-r.left)/r.width)*100))}}
            >
              {/* After (Anime) side */}
              <div style={{
                position:"absolute",inset:0,
                background:`linear-gradient(135deg, #0f172a 0%, rgba(${hexToRgb(animal.accent)},0.15) 50%, #0f172a 100%)`,
                display:"flex",alignItems:"center",justifyContent:"center",
              }}>
                <div style={{textAlign:"center"}}>
                  <div style={{fontSize:80}}>{animal.icon}</div>
                  <div style={{color:animal.accent,fontFamily:"'Exo 2',sans-serif",fontWeight:800,fontSize:18,marginTop:8}}>
                    {animal.desc}
                  </div>
                  <div style={{color:"#475569",fontSize:12,marginTop:4}}>ANIME OUTPUT</div>
                </div>
              </div>
              {/* Before side overlay */}
              <div style={{
                position:"absolute",inset:0,
                clipPath:`inset(0 ${100-sliderPos}% 0 0)`,
                background:"linear-gradient(135deg,#1a1f2e,#0f172a)",
                display:"flex",alignItems:"center",justifyContent:"center",
              }}>
                <div style={{textAlign:"center"}}>
                  <div style={{fontSize:60,opacity:0.4}}>👤</div>
                  <div style={{color:"#334155",fontFamily:"'Exo 2',sans-serif",fontWeight:700,fontSize:14,marginTop:8}}>
                    ORIGINAL
                  </div>
                </div>
              </div>
              {/* Slider handle */}
              <div style={{
                position:"absolute",top:0,bottom:0,left:`${sliderPos}%`,width:2,
                background:"rgba(255,255,255,0.8)",cursor:"ew-resize",
                transform:"translateX(-50%)",
              }}>
                <div style={{
                  position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",
                  width:32,height:32,borderRadius:"50%",
                  background:"#fff",display:"flex",alignItems:"center",justifyContent:"center",
                  fontSize:14,boxShadow:"0 2px 8px rgba(0,0,0,0.4)",
                }}>⟺</div>
              </div>
              {/* Labels */}
              <div style={{position:"absolute",top:12,left:12,background:"rgba(0,0,0,0.6)",padding:"3px 8px",borderRadius:4,fontSize:11,color:"#fff",fontWeight:700}}>BEFORE</div>
              <div style={{position:"absolute",top:12,right:12,background:`rgba(${hexToRgb(animal.accent)},0.8)`,padding:"3px 8px",borderRadius:4,fontSize:11,color:"#fff",fontWeight:700}}>AFTER</div>
            </div>
            {/* Video controls bar */}
            <div style={{
              padding:"12px 16px",
              background:"rgba(15,23,42,0.9)",
              display:"flex",alignItems:"center",gap:12,
            }}>
              <button style={{background:"rgba(6,182,212,0.15)",border:"1px solid rgba(6,182,212,0.3)",borderRadius:8,padding:"6px 12px",color:"#06b6d4",fontSize:16,cursor:"pointer"}}>▶</button>
              <div style={{flex:1,height:4,background:"#1e293b",borderRadius:2,overflow:"hidden"}}>
                <div style={{height:"100%",width:"35%",background:`linear-gradient(90deg,#06b6d4,${animal.accent})`,borderRadius:2}}/>
              </div>
              <span style={{color:"#475569",fontSize:12,fontWeight:600}}>1:24 / 3:45</span>
              <button style={{background:"transparent",border:"none",color:"#475569",fontSize:18,cursor:"pointer"}}>⛶</button>
            </div>
          </Card>

          {/* Stats */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10}}>
            {[
              {label:"Duration",  val:"3:45",     icon:"⏱"},
              {label:"Quality",   val:config.quality||"1080p", icon:"🎬"},
              {label:"Style",     val:config.stylePreset||"Anime", icon:"🎨"},
              {label:"Emotion",   val:config.emotion||"Sad", icon:"💫"},
            ].map(s=>(
              <div key={s.label} style={{
                background:"rgba(15,23,42,0.8)",border:"1px solid #1e293b",
                borderRadius:10,padding:"12px",textAlign:"center",
              }}>
                <div style={{fontSize:20,marginBottom:4}}>{s.icon}</div>
                <div style={{fontSize:13,fontWeight:700,color:"#94a3b8"}}>{s.val}</div>
                <div style={{fontSize:10,color:"#334155",fontWeight:600,textTransform:"uppercase",letterSpacing:"0.5px"}}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Download panel */}
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <Card>
            <div style={{color:"#94a3b8",fontSize:11,fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:14}}>
              Download
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:10}}>
              {[
                {q:"4K",    size:"2.1 GB", icon:"💎", accent:"#f59e0b"},
                {q:"1080p", size:"842 MB", icon:"⭐", accent:"#06b6d4"},
                {q:"720p",  size:"421 MB", icon:"✨", accent:"#8b5cf6"},
              ].map(({q,size,icon,accent})=>(
                <button key={q} onClick={()=>handleDownload(q)} style={{
                  display:"flex",alignItems:"center",gap:12,
                  padding:"12px 14px",
                  background:`rgba(${hexToRgb(accent)},0.06)`,
                  border:`1px solid rgba(${hexToRgb(accent)},0.2)`,
                  borderRadius:10,cursor:"pointer",
                  transition:"all 0.2s",width:"100%",
                }}
                onMouseEnter={e=>{e.currentTarget.style.background=`rgba(${hexToRgb(accent)},0.12)`}}
                onMouseLeave={e=>{e.currentTarget.style.background=`rgba(${hexToRgb(accent)},0.06)`}}
                >
                  <span style={{fontSize:22}}>{icon}</span>
                  <div style={{flex:1,textAlign:"left"}}>
                    <div style={{color:accent,fontWeight:800,fontSize:14}}>{q}</div>
                    <div style={{color:"#475569",fontSize:11}}>{size} · MP4</div>
                  </div>
                  <span style={{color:accent,fontSize:18}}>↓</span>
                </button>
              ))}
            </div>
          </Card>

          <Card>
            <div style={{color:"#94a3b8",fontSize:11,fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:14}}>
              Share & Export
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              {["📱 Save to Gallery","📤 Share Link","🎵 Export Audio Only","🖼 Export Thumbnail"].map(action=>(
                <button key={action} style={{
                  padding:"10px 12px",background:"rgba(15,23,42,0.6)",
                  border:"1px solid #1e293b",borderRadius:8,
                  color:"#64748b",fontSize:13,cursor:"pointer",
                  textAlign:"left",transition:"all 0.2s",fontWeight:500,
                }}
                onMouseEnter={e=>{e.currentTarget.style.color="#e2e8f0";e.currentTarget.style.borderColor="#334155"}}
                onMouseLeave={e=>{e.currentTarget.style.color="#64748b";e.currentTarget.style.borderColor="#1e293b"}}
                >{action}</button>
              ))}
            </div>
          </Card>

          <Card>
            <div style={{color:"#94a3b8",fontSize:11,fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase",marginBottom:12}}>
              AI Summary
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8,fontSize:12,color:"#475569"}}>
              <div>🐾 Transformed <strong style={{color:"#94a3b8"}}>3 characters</strong> detected</div>
              <div>💬 Lip-sync accuracy: <strong style={{color:"#06b6d4"}}>97.4%</strong></div>
              <div>🎤 Voice conversion: <strong style={{color:"#a78bfa"}}>complete</strong></div>
              <div>🎵 Music preserved: <strong style={{color:"#f59e0b"}}>100%</strong></div>
              <div>📝 Subtitles: <strong style={{color:"#4ade80"}}>synced</strong></div>
            </div>
          </Card>

          <GlowButton onClick={onNewVideo} variant="ghost" style={{width:"100%",padding:"12px",borderRadius:10}}>
            ＋ Transform New Video
          </GlowButton>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   HISTORY SIDEBAR
───────────────────────────────────────────── */
function HistorySidebar({ currentView }) {
  const [history] = useState([
    {id:1,name:"dance_video.mp4",animal:"🐺",style:"Wolf Anime",quality:"1080p",date:"Today"},
    {id:2,name:"song_cover.mp4", animal:"🦁",style:"Lion King",quality:"4K",    date:"Yesterday"},
    {id:3,name:"mv_remix.mp4",   animal:"🦊",style:"Fox Anime", quality:"1080p",date:"2 days ago"},
    {id:4,name:"concert.mp4",    animal:"🐼",style:"Panda Cute",quality:"720p", date:"3 days ago"},
  ]);

  return (
    <div style={{
      width:220,flexShrink:0,
      borderRight:"1px solid rgba(30,41,59,0.8)",
      padding:"20px 16px",
      display:"flex",flexDirection:"column",gap:16,
      background:"rgba(8,12,24,0.7)",
    }}>
      <div style={{color:"#334155",fontSize:10,fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase"}}>
        Video History
      </div>
      {history.map(h=>(
        <div key={h.id} style={{
          padding:"10px 10px",
          background:"rgba(15,23,42,0.6)",
          border:"1px solid #1e293b",
          borderRadius:8,cursor:"pointer",
          transition:"all 0.2s",
        }}
        onMouseEnter={e=>{e.currentTarget.style.borderColor="#334155"}}
        onMouseLeave={e=>{e.currentTarget.style.borderColor="#1e293b"}}
        >
          <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:4}}>
            <span style={{fontSize:16}}>{h.animal}</span>
            <span style={{color:"#94a3b8",fontSize:11,fontWeight:600,flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
              {h.style}
            </span>
          </div>
          <div style={{color:"#334155",fontSize:10,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
            {h.name}
          </div>
          <div style={{display:"flex",justifyContent:"space-between",marginTop:6}}>
            <span style={{
              fontSize:9,fontWeight:700,letterSpacing:"0.5px",
              color:"#06b6d4",background:"rgba(6,182,212,0.1)",
              padding:"1px 6px",borderRadius:3,
            }}>{h.quality}</span>
            <span style={{fontSize:9,color:"#334155"}}>{h.date}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ─────────────────────────────────────────────
   UTILITY
───────────────────────────────────────────── */
function hexToRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? `${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}` : "6,182,212";
}

/* ─────────────────────────────────────────────
   MAIN APP
───────────────────────────────────────────── */
export default function App() {
  const [view, setView]     = useState("upload");   // upload | configure | processing | results
  const [file, setFile]     = useState(null);
  const [config, setConfig] = useState({});

  const steps = ["upload","configure","processing","results"];
  const stepIdx = steps.indexOf(view);

  return (
    <div style={{
      minHeight:"100vh",
      background:"radial-gradient(ellipse 100% 60% at 50% -20%, rgba(6,182,212,0.08) 0%, #080c18 60%)",
      fontFamily:"'Inter','Segoe UI',sans-serif",
      color:"#e2e8f0",
      display:"flex",
      flexDirection:"column",
    }}>
      <link rel="preconnect" href="https://fonts.googleapis.com"/>
      <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@700;800;900&display=swap" rel="stylesheet"/>

      <ParticlesBg/>

      {/* TOP NAV */}
      <nav style={{
        position:"sticky",top:0,zIndex:100,
        background:"rgba(8,12,24,0.9)",
        borderBottom:"1px solid rgba(30,41,59,0.8)",
        backdropFilter:"blur(20px)",
        padding:"0 24px",
        height:60,display:"flex",alignItems:"center",justifyContent:"space-between",
      }}>
        <Logo/>
        {/* Step indicator */}
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          {["Upload","Configure","Processing","Results"].map((s,i)=>(
            <div key={s} style={{display:"flex",alignItems:"center",gap:8}}>
              <div style={{
                width:28,height:28,borderRadius:"50%",
                background: i < stepIdx ? "rgba(6,182,212,0.2)" : i===stepIdx ? "rgba(6,182,212,0.3)" : "rgba(15,23,42,0.8)",
                border: i <= stepIdx ? "1.5px solid #06b6d4" : "1.5px solid #1e293b",
                display:"flex",alignItems:"center",justifyContent:"center",
                fontSize:10,fontWeight:700,
                color: i <= stepIdx ? "#06b6d4" : "#334155",
              }}>
                {i < stepIdx ? "✓" : i+1}
              </div>
              <span style={{fontSize:12,color: i===stepIdx ? "#e2e8f0" : "#334155",display:i===3&&view!=="results"?"none":"block"}}>
                {s}
              </span>
              {i < 3 && <div style={{width:24,height:1,background:i < stepIdx ? "#06b6d4" : "#1e293b"}}/>}
            </div>
          ))}
        </div>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <div style={{fontSize:12,color:"#334155"}}>Personal Studio</div>
          <div style={{
            width:32,height:32,borderRadius:"50%",
            background:"linear-gradient(135deg,#06b6d4,#8b5cf6)",
            display:"flex",alignItems:"center",justifyContent:"center",
            fontSize:14,
          }}>🎭</div>
        </div>
      </nav>

      {/* MAIN LAYOUT */}
      <div style={{display:"flex",flex:1,position:"relative",zIndex:1}}>
        {/* Sidebar (hide during processing) */}
        {view !== "processing" && <HistorySidebar currentView={view}/>}

        {/* Content */}
        <div style={{flex:1,padding:"28px 32px",overflowY:"auto"}}>
          {view === "upload" && (
            <UploadView onFileSelected={f => { setFile(f); setView("configure"); }}/>
          )}
          {view === "configure" && (
            <ConfigView
              file={file}
              onStart={cfg => { setConfig(cfg); setView("processing"); }}
            />
          )}
          {view === "processing" && (
            <ProcessingView
              config={config}
              onComplete={() => setView("results")}
            />
          )}
          {view === "results" && (
            <ResultsView
              config={config}
              onNewVideo={() => { setFile(null); setConfig({}); setView("upload"); }}
            />
          )}
        </div>
      </div>

      {/* FOOTER */}
      <footer style={{
        borderTop:"1px solid rgba(30,41,59,0.5)",
        padding:"10px 24px",
        display:"flex",justifyContent:"space-between",alignItems:"center",
        background:"rgba(8,12,24,0.7)",
        position:"relative",zIndex:1,
      }}>
        <span style={{fontSize:11,color:"#1e293b"}}>Animal Anime Video Studio · Personal Use Only · Localhost</span>
        <span style={{fontSize:11,color:"#1e293b"}}>GPU Accelerated · CUDA · RTX Optimized</span>
      </footer>
    </div>
  );
}
