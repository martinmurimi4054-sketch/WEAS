# 🎬 Animal Anime Video Studio
## Complete Installation & GPU Setup Guide

---

## System Requirements

| Component     | Minimum                   | Recommended                  |
|---------------|---------------------------|------------------------------|
| GPU           | NVIDIA RTX 3060 (12 GB)   | RTX 4090 / A100 (24 GB+)     |
| VRAM          | 10 GB                     | 24 GB                        |
| RAM           | 32 GB                     | 64 GB                        |
| Storage       | 100 GB SSD                | 500 GB NVMe SSD              |
| OS            | Windows 10/11 or Ubuntu 22| Ubuntu 22.04 LTS (preferred) |
| Python        | 3.10+                     | 3.11                         |
| CUDA          | 11.8                      | 12.1                         |
| Node.js       | 18+                       | 20 LTS                       |

---

## Part 1 — GPU Driver & CUDA Setup

### Windows
```powershell
# 1. Install NVIDIA drivers from https://www.nvidia.com/drivers
# 2. Install CUDA 11.8 from https://developer.nvidia.com/cuda-11-8-0-download-archive
# 3. Verify:
nvcc --version
nvidia-smi
```

### Ubuntu/Linux
```bash
# NVIDIA driver
sudo apt install nvidia-driver-535

# CUDA 11.8
wget https://developer.download.nvidia.com/compute/cuda/11.8.0/local_installers/cuda_11.8.0_520.61.05_linux.run
sudo sh cuda_11.8.0_520.61.05_linux.run

# Add to ~/.bashrc:
export PATH=/usr/local/cuda-11.8/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda-11.8/lib64:$PATH

source ~/.bashrc
nvcc --version   # should show 11.8
```

---

## Part 2 — Backend Setup

```bash
cd AnimalAnimeStudio/backend

# Create and activate virtual environment
python -m venv venv
source venv/bin/activate          # Linux/Mac
# venv\Scripts\activate.bat       # Windows

# Install PyTorch with CUDA 11.8 support FIRST
pip install torch==2.2.2 torchvision==0.17.2 torchaudio==0.17.2 \
    --index-url https://download.pytorch.org/whl/cu118

# Verify GPU is visible
python -c "import torch; print(torch.cuda.is_available(), torch.cuda.get_device_name(0))"

# Install remaining dependencies
pip install -r requirements.txt

# Install FFmpeg
# Ubuntu:
sudo apt install ffmpeg
# Windows: https://ffmpeg.org/download.html  (add to PATH)
```

### Download AI Models

```bash
# Create model directories
mkdir -p models/{animatediff,controlnet,rvc,wav2lip,insightface}

# 1. AnimateDiff Motion Adapter (auto-downloaded by diffusers on first run)
python -c "from diffusers import MotionAdapter; MotionAdapter.from_pretrained('guoyww/animatediff-motion-adapter-v1-5-2')"

# 2. Wav2Lip model (lip sync)
wget "https://github.com/Rudrabha/Wav2Lip/releases/download/v1.0/wav2lip_gan.pth" \
    -O models/wav2lip/wav2lip_gan.pth

# 3. InsightFace buffalo model (auto-downloaded on first FaceAnalysis use)
python -c "from insightface.app import FaceAnalysis; FaceAnalysis(providers=['CUDAExecutionProvider']).prepare(ctx_id=0)"

# 4. OpenAI Whisper (downloads on first use, ~150MB for 'base')
python -c "import whisper; whisper.load_model('base')"

# 5. RVC Anime Voice Models — download from:
#    https://huggingface.co/datasets/SayanoAI/RVC-Studio/tree/main
#    Place .pth files in models/rvc/
```

### Start Backend
```bash
cd backend
uvicorn main:app --reload --host 0.0.0.0 --port 8000
# API docs at: http://localhost:8000/docs
```

---

## Part 3 — Frontend Setup

```bash
cd AnimalAnimeStudio/frontend

# Install Node dependencies
npm install

# Start development server
npm run dev
# Opens at: http://localhost:3000
```

### Environment Variables (frontend/.env)
```env
VITE_API_URL=http://localhost:8000
VITE_APP_NAME=Animal Anime Video Studio
```

### Production Build
```bash
npm run build
# Outputs to frontend/dist/
# Serve with: npx serve dist
```

---

## Part 4 — ComfyUI Integration (Advanced)

For maximum quality, use ComfyUI as the diffusion backend:

```bash
# Install ComfyUI
git clone https://github.com/comfyanonymous/ComfyUI.git
cd ComfyUI
pip install -r requirements.txt

# Install AnimateDiff nodes
cd custom_nodes
git clone https://github.com/Kosinkadink/ComfyUI-AnimateDiff-Evolved.git
git clone https://github.com/Fannovel16/comfyui_controlnet_aux.git

# Download models into ComfyUI/models/checkpoints/
# Recommended: epiCRealism, DreamShaper XL

# Start ComfyUI server
cd ..
python main.py --port 8188 --listen
```

In `backend/.env`:
```env
COMFYUI_URL=http://localhost:8188
USE_COMFYUI=true
```

---

## Part 5 — Full Stack Launch Script

### Linux/Mac (start_studio.sh)
```bash
#!/bin/bash
echo "🎬 Starting Animal Anime Video Studio..."

# Backend
cd backend
source venv/bin/activate
uvicorn main:app --host 0.0.0.0 --port 8000 &
BACKEND_PID=$!

# Frontend
cd ../frontend
npm run dev &
FRONTEND_PID=$!

echo "✅ Backend:  http://localhost:8000"
echo "✅ Frontend: http://localhost:3000"
echo "📖 API Docs: http://localhost:8000/docs"
echo ""
echo "Press Ctrl+C to stop all services"

# Wait and cleanup
trap "kill $BACKEND_PID $FRONTEND_PID; exit" INT
wait
```

```bash
chmod +x start_studio.sh
./start_studio.sh
```

### Windows (start_studio.bat)
```batch
@echo off
echo Starting Animal Anime Video Studio...

start "Backend" cmd /k "cd backend && venv\Scripts\activate && uvicorn main:app --host 0.0.0.0 --port 8000"
timeout /t 3
start "Frontend" cmd /k "cd frontend && npm run dev"

echo.
echo  Backend:  http://localhost:8000
echo  Frontend: http://localhost:3000
echo  API Docs: http://localhost:8000/docs
```

---

## Part 6 — Folder Structure

```
AnimalAnimeStudio/
├── frontend/
│   ├── src/
│   │   ├── App.jsx          ← Main React app (all UI screens)
│   │   ├── main.jsx
│   │   └── index.css
│   ├── package.json
│   └── vite.config.js
│
├── backend/
│   ├── main.py              ← FastAPI entry point
│   ├── requirements.txt
│   ├── routes/
│   │   ├── video_routes.py  ← Upload & transform endpoints
│   │   ├── job_routes.py    ← Progress polling endpoints
│   │   └── audio_routes.py  ← Transcription endpoints
│   ├── services/
│   │   ├── ai_pipeline.py   ← Full AI orchestration (core engine)
│   │   └── job_manager.py   ← Job tracking
│   ├── models/
│   │   ├── animatediff/
│   │   ├── controlnet/
│   │   ├── rvc/             ← Place .pth voice models here
│   │   ├── wav2lip/         ← wav2lip_gan.pth
│   │   └── insightface/
│   ├── uploads/             ← Temporary input videos
│   └── outputs/             ← Final rendered videos
│
└── docs/
    ├── INSTALL.md           ← This file
    ├── API.md               ← API reference
    └── GPU_GUIDE.md         ← GPU optimization tips
```

---

## Part 7 — GPU Optimization Tips

### VRAM Management
```python
# In ai_pipeline.py — add to CharacterTransformer._load_pipeline():
self._pipe.enable_model_cpu_offload()   # for 8-12 GB VRAM
self._pipe.enable_vae_slicing()         # process VAE frame-by-frame
self._pipe.enable_vae_tiling()          # large-resolution tiling
```

### Speed vs Quality Trade-offs
| Setting         | Faster              | Higher Quality      |
|-----------------|---------------------|---------------------|
| Inference steps | 15–20               | 25–50               |
| Guidance scale  | 5–7                 | 7–12                |
| Resolution      | 512×512 per frame   | 768×768+            |
| Scheduler       | LCM (4–8 steps)     | DDIM (25+ steps)    |

### Multi-GPU Setup
```bash
# Set CUDA device in main.py
export CUDA_VISIBLE_DEVICES=0,1   # Use both GPUs
```

---

## Part 8 — Troubleshooting

| Error                            | Solution |
|----------------------------------|----------|
| `CUDA out of memory`             | Enable `enable_model_cpu_offload()` or reduce resolution |
| `ModuleNotFoundError: insightface`| `pip install insightface onnxruntime-gpu` |
| `ffmpeg: command not found`      | Install FFmpeg and add to PATH |
| `Port 8000 already in use`       | `lsof -ti:8000 | xargs kill -9` |
| Blank/corrupt output video       | Check VRAM, reduce inference steps |
| Voice sounds robotic             | Lower `f0_method` in RVC config to `harvest` |
| Lip sync slightly off            | Set `--pads 0 15 0 0` in Wav2Lip args |

---

## API Quick Reference

```http
POST /api/video/upload          Upload video → { job_id }
POST /api/video/transform       Start AI job → { job_id, status }
GET  /api/jobs/{job_id}         Poll progress → { pct, message, status }
GET  /api/video/download/{id}   Download final MP4
POST /api/audio/transcribe/{id} Whisper lyrics extraction
GET  /health                    GPU & server status
```

---

*Animal Anime Video Studio — Personal Use Only*
*Built with: AnimateDiff · Wav2Lip · RVC · Whisper · FFmpeg · FastAPI · React*
