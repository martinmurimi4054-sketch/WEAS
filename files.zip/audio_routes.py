"""Audio routes: voice preview generation and Whisper transcription."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import os, subprocess

router = APIRouter()


class TranscribeRequest(BaseModel):
    job_id: str
    language: str = "auto"


@router.post("/transcribe/{job_id}")
async def transcribe_audio(job_id: str):
    """Run Whisper on the uploaded video's audio and return a transcript."""
    input_path = os.path.join("uploads", job_id)
    if not os.path.isdir(input_path):
        raise HTTPException(404, "Job not found")

    # Find input file
    for f in os.listdir(input_path):
        if f.startswith("input"):
            video_file = os.path.join(input_path, f)
            break
    else:
        raise HTTPException(404, "Input video not found")

    # Extract audio
    audio_out = os.path.join(input_path, "audio_preview.wav")
    subprocess.run(
        ["ffmpeg", "-y", "-i", video_file, "-vn", "-ar", "16000", "-ac", "1", audio_out],
        check=True, capture_output=True,
    )

    # Whisper transcription
    try:
        import whisper
        model  = whisper.load_model("base")
        result = model.transcribe(audio_out, word_timestamps=True)
        return {
            "text":     result["text"],
            "segments": result.get("segments", []),
            "language": result.get("language", "unknown"),
        }
    except ImportError:
        return {"error": "Whisper not installed. Run: pip install openai-whisper"}
