"""In-memory job manager with optional SQLite persistence."""
import json, os, time, asyncio, shutil
from typing import Optional, Dict, Any


class JobManager:
    """
    Thread-safe in-memory job store.
    For personal use; swap in Redis or SQLite for multi-user.
    """
    def __init__(self):
        self._jobs: Dict[str, Dict[str, Any]] = {}

    def create(self, job_id: str, data: dict) -> dict:
        record = {
            "job_id":     job_id,
            "status":     "created",
            "created_at": time.time(),
            "pct":        0,
            "message":    "Ready",
            **data,
        }
        self._jobs[job_id] = record
        return record

    def get(self, job_id: str) -> Optional[dict]:
        return self._jobs.get(job_id)

    def update(self, job_id: str, data: dict):
        if job_id in self._jobs:
            self._jobs[job_id].update(data)

    def all_jobs(self) -> list:
        return sorted(self._jobs.values(), key=lambda j: j["created_at"], reverse=True)

    def active_count(self) -> int:
        return sum(1 for j in self._jobs.values() if j["status"] not in ("done","error","created"))

    def delete(self, job_id: str):
        self._jobs.pop(job_id, None)


class FileManager:
    UPLOAD_DIR = "uploads"
    OUTPUT_DIR = "outputs"
    TEMP_DIR   = "temp"

    async def clean_temp(self):
        """Remove temporary processing files older than 1 hour."""
        for d in [self.TEMP_DIR]:
            if os.path.exists(d):
                shutil.rmtree(d, ignore_errors=True)
        os.makedirs(self.TEMP_DIR, exist_ok=True)

    async def clean_uploads(self, job_id: str):
        """Delete raw upload after processing completes."""
        path = os.path.join(self.UPLOAD_DIR, job_id)
        shutil.rmtree(path, ignore_errors=True)
