"""
Animal Anime Video Studio - FastAPI Backend
Personal Use Only | GPU Accelerated
"""
from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from typing import Optional
import uuid, os, shutil, asyncio, logging

from routes import video_routes, job_routes, audio_routes
from services.job_manager import JobManager
from services.file_manager import FileManager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("AnimeStudio")

app = FastAPI(
    title="Animal Anime Video Studio",
    description="AI-powered anime animal video transformation engine",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Services
job_manager  = JobManager()
file_manager = FileManager()

# Routers
app.include_router(video_routes.router, prefix="/api/video",  tags=["Video"])
app.include_router(job_routes.router,   prefix="/api/jobs",   tags=["Jobs"])
app.include_router(audio_routes.router, prefix="/api/audio",  tags=["Audio"])

# Static output files
os.makedirs("outputs", exist_ok=True)
app.mount("/outputs", StaticFiles(directory="outputs"), name="outputs")


@app.get("/health")
async def health():
    import torch
    gpu_available = torch.cuda.is_available()
    gpu_name      = torch.cuda.get_device_name(0) if gpu_available else "CPU only"
    return {
        "status":    "online",
        "gpu":       gpu_name,
        "cuda":      gpu_available,
        "jobs_active": job_manager.active_count(),
    }


@app.on_event("startup")
async def startup():
    logger.info("🎬 Animal Anime Video Studio starting...")
    logger.info("🤖 Loading AI models (this may take 30–60s on first run)...")
    await file_manager.clean_temp()
    logger.info("✅ Server ready at http://localhost:8000")


@app.on_event("shutdown")
async def shutdown():
    logger.info("Shutting down — cleaning temporary files...")
    await file_manager.clean_temp()
